﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        UserDetails BAL = new UserDetails();
        if (Session["uid_gender"] == null)
        {
            Response.Redirect("~/Default.aspx?refPage=" + Page.AppRelativeVirtualPath);
        }
        else 
        {
            if (!IsPostBack)
            {
                try
                {
                    BAL.User_Id = Session["uid_gender"].ToString().Split('_')[0];
                    lblUser.Text = BAL.GetName();
                }
                catch (Exception ex)
                {
                    WebMsgBox.Show(ex.Message);
                }
            }
        }
    }
    protected void btnLogout_Click(object sender, EventArgs e)
    {
        Session.Abandon();
        Response.Redirect("~/Default.aspx");
    }
}
