﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using CuteWebUI;
using System.Data;

/// <summary>
/// Summary description for Album
/// </summary>
public class Album 
{
    DbManager ObjDAL = new DbManager();

	public Album()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public string   CreateAlbumDirectory(string DirName,string UserID,string Gender)
    {
        try
        {
            
            if (!Directory.Exists(DirName))
            {
                Directory.CreateDirectory(DirName);

                Dictionary<string, string> Param = new Dictionary<string, string>();
                Param.Add("@MemberId", UserID);
                if (Gender == "Male")
                {
                    Param.Add("@ProfilePhoto", "MaleProfile.jpg");
                }
                else
                {
                    Param.Add("@ProfilePhoto", "FeMaleProfile.jpg");
                }
                Param.Add("@CreatedDate", DateTime.Today.ToString());
                Param.Add("@Permission", "0");
                Param.Add("@FolderName", UserID);
                Param.Add("@AlbumName", UserID);
                DbManager.ExecuteNonQuerySP("SP_Insert_Album", Param);


                return "Directory Created Succsefully ";
            }
            else
            {
                return "You Are Already Created Directory";
            }


        }
        catch
        {
            throw;
        }
            finally
        {
        }
        
    }
    public DataTable GetAllImages(string Path)
    {
        DataTable dt = new DataTable();
        try
        {
            if (Directory.Exists(Path))
            {
               
                dt.Columns.Add("FilePath", typeof(string));


                System.IO.DirectoryInfo objDI = new System.IO.DirectoryInfo(Path + "/");
                    string[] extensions = new[] { ".jpg", ".gif", ".bmp",".png" };
                
FileInfo[] fileSizes =
    objDI.EnumerateFiles()
         .Where(f => extensions.Contains(f.Extension.ToLower()))
         .ToArray();
                

                foreach (FileInfo Fi in fileSizes)
                {
                    DataRow dr = dt.NewRow();
                    dr["FilePath"] = Fi.Directory.Name + @"/" + Fi.Name;

                    dt.Rows.Add(dr);
                }


               
            }
            return dt;
        }
        catch
        {
            throw;
        }
        finally 
        { 
             
        }
      
    }


  
    public void DeleteImages(string Path)
    {

    }
    public string  SetProfilePicture(string FileName,string UserID)
    {
        try
        {

           
              

                Dictionary<string, string> Param = new Dictionary<string, string>();
                Param.Add("@MemberId", UserID);
                Param.Add("@ProfilePhoto", FileName);

                if (DbManager.ExecuteNonQuerySP("[SP_Update_Album_ProfilePic]", Param) > 0)
                {
                    return "Your Profile Picture Updated.";
                }
                else
                {
                    return "Some Probleme In Server Plese Try Later";
                }


          
        }
        catch
        {
            throw;
        }
        finally
        {
        }
    }
    public string  GetProfilePicture(string MemberId)
    {
        try
        {

           
             

                Dictionary<string, string> Param = new Dictionary<string, string>();
                Param.Add("@MemberId", MemberId);
                DataSet ds= DbManager.GetDataSetSP("SP_Select_Album", Param);
                return  ds.Tables[0].Rows[0]["ProfilePhoto"].ToString();

              


        }
        catch
        {
            throw;
        }
        finally
        {
        }
    }
    public string DeleteFile(string DirName,string fielName)
    {
        try
        {

            if (Directory.Exists(DirName) && File.Exists(DirName+@"\"+fielName))
            {
                File.Delete(DirName + @"\" + fielName);
                return "File Deleted Succsefully ";
            }
            else
            {
                return "File Does Not Exist. Please Try Again Later";
            }
        }
        catch
        {
            return "Some Problem With Server. Please Try Again Later";
        }
        finally
        {
        }
    }
}